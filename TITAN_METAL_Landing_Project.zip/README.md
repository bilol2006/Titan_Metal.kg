# TITAN METAL Landing

1. Загрузите файлы на GitHub.
2. Включите GitHub Pages.
3. При желании добавьте logo.png в assets и вставьте его в index.html.
